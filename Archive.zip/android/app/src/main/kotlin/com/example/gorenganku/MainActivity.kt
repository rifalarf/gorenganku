package com.example.gorenganku

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
